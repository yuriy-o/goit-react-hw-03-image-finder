// Компонент елемента списку із зображенням.
// Створює DOM - елемент наступної структури.

const { ImageGalleryItem, Image } = require('./ImageGalleryItem.styled');

<ImageGalleryItem>
  <Image src="" alt="" />
</ImageGalleryItem>;
