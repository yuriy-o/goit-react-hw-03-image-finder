// Список карток зображень.
// Створює DOM - елемент наступної структури.

const { ImageGalleryList } = require('./ImageGallery.styled');

export const ImageGallery = () => {
  <ImageGalleryList>{/* Набір <li> із зображеннями */}</ImageGalleryList>;
};
